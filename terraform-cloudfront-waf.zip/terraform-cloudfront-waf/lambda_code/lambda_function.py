lambda_code/lambda_functions.py
import json
import os
import boto3
from datetime import datetime

def handler(event, context):
    """
    Lambda handler function for API Gateway with WAF and CloudFront
    """
    
    # Parse tags from environment
    tags_env = os.environ.get('TAGS', '{}')
    tags = json.loads(tags_env) if tags_env else {}
    
    # Extract request info
    http_method = event.get('httpMethod', 'GET')
    path = event.get('path', '/')
    headers = event.get('headers', {})
    query_params = event.get('queryStringParameters', {})
    
    # Get client info
    client_ip = headers.get('x-forwarded-for', 'unknown')
    user_agent = headers.get('user-agent', 'unknown')
    
    # Generate response with tag info
    response_body = {
        "status": "success",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "request": {
            "method": http_method,
            "path": path,
            "client_ip": client_ip,
            "user_agent": user_agent
        },
        "architecture": "Client → CloudFront → AWS WAF (BLOCK MODE) → API Gateway → Lambda",
        "environment": os.environ.get('ENVIRONMENT', 'unknown'),
        "tags": tags,
        "waf_protected": True,
        "cloudfront_cdn": True
    }
    
    # Add query params if present
    if query_params:
        response_body["request"]["query_parameters"] = query_params
    
    # Return response
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-API-Key",
            "Access-Control-Allow-Methods": "OPTIONS,GET,POST,PUT,DELETE,PATCH",
            "X-WAF-Protected": "true",
            "X-CloudFront-Enabled": "true",
            "X-Environment": os.environ.get('ENVIRONMENT', 'unknown')
        },
        "body": json.dumps(response_body, indent=2)
    }
